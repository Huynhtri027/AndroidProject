/****************************************************************************************************
 * The ReadSensor Arduino Library is an open sources for every body who work with sensor and arduino.
 *
 * @Created by Ngo Van Hoa <nvhoa7602@gmail.com> 25, September, 2016.
 *
 * @Copyright (C) 2016.
 *
 * Full sources: https://github.com/nvh7602/ReadSensors
 *
 *****************************************************************************************************/
#ifndef SDCard_h
#define SDCard_h

#include <SPI.h>
#include <SD.h>

typedef unsigned char byte;

class SDCard{
	public:
		SDCard();
		void setUp();
		void writeData(String, String);
};

#endif
